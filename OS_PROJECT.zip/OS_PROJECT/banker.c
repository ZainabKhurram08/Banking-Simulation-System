#include <stdio.h>
#include <string.h>
#include "common.h"
#include "banker.h"

void banker_init(BankerState* state, int num_customers, int num_resources) {
    state->num_customers  = num_customers;
    state->num_resources  = num_resources;

    for (int i = 0; i < num_customers; i++) {
        for (int j = 0; j < num_resources; j++) {
            state->allocation[i][j] = 0;
            state->maximum[i][j]    = 0;
            state->need[i][j]       = 0;
        }
    }
    for (int j = 0; j < num_resources; j++)
        state->available[j] = 0;
}

int safety_check(BankerState* state, int* safe_sequence) {
    int work[MAX_RESOURCES];
    int finish[MAX_CUSTOMERS];
    int seq_idx = 0;

    for (int j = 0; j < state->num_resources; j++)
        work[j] = state->available[j];

    for (int i = 0; i < state->num_customers; i++)
        finish[i] = 0;

    int progress = 1;
    while (progress) {
        progress = 0;
        for (int i = 0; i < state->num_customers; i++) {
            if (finish[i]) continue;

            int can_run = 1;
            for (int j = 0; j < state->num_resources; j++) {
                if (state->need[i][j] > work[j]) {
                    can_run = 0;
                    break;
                }
            }

            if (can_run) {
                for (int j = 0; j < state->num_resources; j++)
                    work[j] += state->allocation[i][j];

                finish[i]                = 1;
                safe_sequence[seq_idx++] = i;
                progress                 = 1;
            }
        }
    }

    for (int i = 0; i < state->num_customers; i++) {
        if (!finish[i])
            return STATUS_UNSAFE;
    }
    return STATUS_SAFE;
}

int request_resources(BankerState* state, int customer_id, int* request) {
    for (int j = 0; j < state->num_resources; j++) {
        if (request[j] > state->need[customer_id][j]) {
            printf("  DENIED   Customer %d  Exceeds maximum need\n", customer_id);
            return STATUS_FAILED;
        }
        if (request[j] > state->available[j]) {
            printf("  WAIT     Customer %d  Resources not available\n", customer_id);
            return STATUS_FAILED;
        }
    }

    for (int j = 0; j < state->num_resources; j++) {
        state->available[j]              -= request[j];
        state->allocation[customer_id][j] += request[j];
        state->need[customer_id][j]       -= request[j];
    }

    int safe_sequence[MAX_CUSTOMERS];
    int result = safety_check(state, safe_sequence);

    if (result == STATUS_SAFE) {
        printf("  GRANTED  Customer %d  System is SAFE\n", customer_id);
        print_safe_sequence(safe_sequence, state->num_customers);
        return STATUS_SUCCESS;
    } else {
        for (int j = 0; j < state->num_resources; j++) {
            state->available[j]              += request[j];
            state->allocation[customer_id][j] -= request[j];
            state->need[customer_id][j]       += request[j];
        }
        printf("  DENIED   Customer %d  Would cause UNSAFE state\n", customer_id);
        return STATUS_FAILED;
    }
}

void release_resources(BankerState* state, int customer_id, int* release) {
    for (int j = 0; j < state->num_resources; j++) {
        state->available[j]              += release[j];
        state->allocation[customer_id][j] -= release[j];
        state->need[customer_id][j]       += release[j];
    }
    printf("  RELEASED Customer %d resources returned to pool\n", customer_id);
}

void print_safe_sequence(int* sequence, int size) {
    printf("  Safe sequence  →  ");
    for (int i = 0; i < size; i++)
        printf("P%d ", sequence[i]);
    printf("\n");
}

void run_test_cases(BankerState* state) {
    printf("\n");

    BankerState test;
    banker_init(&test, 5, 3);

    int available[]   = {3, 3, 2};
    int maximum[5][3] = {
        {7, 5, 3},
        {3, 2, 2},
        {9, 0, 2},
        {2, 2, 2},
        {4, 3, 3}
    };
    int allocation[5][3] = {
        {0, 1, 0},
        {2, 0, 0},
        {3, 0, 2},
        {2, 1, 1},
        {0, 0, 2}
    };

    for (int j = 0; j < 3; j++)
        test.available[j] = available[j];

    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++) {
            test.maximum[i][j]    = maximum[i][j];
            test.allocation[i][j] = allocation[i][j];
            test.need[i][j]       = maximum[i][j] - allocation[i][j];
        }
    }

    int safe_seq[MAX_CUSTOMERS];

    printf("  Test 1  Safe State Check\n");
    int result = safety_check(&test, safe_seq);
    if (result == STATUS_SAFE) {
        printf("  Result   System is in SAFE state\n");
        print_safe_sequence(safe_seq, test.num_customers);
    } else {
        printf("  Result   System is in UNSAFE state\n");
    }

    printf("\n  Test 2  Valid Loan Request  P1 requests {1,0,2}\n");
    int req1[3] = {1, 0, 2};
    request_resources(&test, 1, req1);

    printf("\n  Test 3  Unsafe Loan Request  P0 requests {7,4,3}\n");
    int req2[3] = {7, 4, 3};
    request_resources(&test, 0, req2);

    printf("\n  Test 4  Exceeds Maximum Need  P0 requests {8,1,1}\n");
    int req3[3] = {8, 1, 1};
    request_resources(&test, 0, req3);

    printf("\n  Test 5  Resource Release  P1 releases {2,0,0}\n");
    int rel1[3] = {2, 0, 0};
    release_resources(&test, 1, rel1);
}
