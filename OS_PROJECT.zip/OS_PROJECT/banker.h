#ifndef BANKER_H
#define BANKER_H
#include "common.h"
void banker_init(BankerState* state, int num_customers, int num_resources);
int  safety_check(BankerState* state, int* safe_sequence);
int  request_resources(BankerState* state, int customer_id, int* request);
void release_resources(BankerState* state, int customer_id, int* release);
void print_safe_sequence(int* sequence, int size);
void run_test_cases(BankerState* state);

#endif
