#ifndef MEMORY_H
#define MEMORY_H
#include "common.h"
void memory_init(MemoryState* fifo, MemoryState* lru, int num_frames);
int  fifo_replace(MemoryState* state, int page);
int  lru_replace(MemoryState* state, int page, int* lru_order, int access_index);
void page_access_fifo(MemoryState* state, int page);
void page_access_lru(MemoryState* state, int page, int* lru_order, int access_index);
void run_fifo(MemoryState* state, int* pages, int num_pages);
void run_lru(MemoryState* state, int* pages, int num_pages);
void print_page_faults(MemoryState* fifo, MemoryState* lru);
void compare_algorithms(MemoryState* fifo, MemoryState* lru);
#endif
