#ifndef SYNC_H
#define SYNC_H
#include "common.h"
void sync_init();
void sync_destroy();
void mutex_lock_account();
void mutex_unlock_account();
void sem_wait_deposit();
void sem_post_deposit();
int  deposit(Account* acc, int amount, int customer_id);
int  withdraw(Account* acc, int amount, int customer_id);
void log_transaction(int customer_id, const char* op, int amount, int balance_after, int status);
void print_race_log();
#endif
