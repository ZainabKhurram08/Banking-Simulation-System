#include <stdio.h>
#include <string.h>
#include "common.h"
#include "sync.h"

pthread_mutex_t account_mutex;
sem_t           deposit_sem;

static int transaction_count = 0;

void sync_init() {
    pthread_mutex_init(&account_mutex, NULL);
    sem_init(&deposit_sem, 0, MAX_CONCURRENT_DEPOSITS);

    FILE* f = fopen(RACE_LOG_FILE, "w");
    if (f) {
        fprintf(f, "RACE CONDITION PROOF LOG\n");
        fprintf(f, "Mutex: pthread_mutex_t  |  Semaphore: max %d concurrent deposits\n\n", MAX_CONCURRENT_DEPOSITS);
        fprintf(f, "%-6s  %-14s  %-10s  %-8s  %-14s  %-6s\n",
                "TXN", "CUSTOMER_ID", "OPERATION", "AMOUNT", "BALANCE_AFTER", "STATUS");
        fprintf(f, "\n");
        fclose(f);
    }
}

void sync_destroy() {
    pthread_mutex_destroy(&account_mutex);
    sem_destroy(&deposit_sem);
}

void mutex_lock_account() {
    pthread_mutex_lock(&account_mutex);
}

void mutex_unlock_account() {
    pthread_mutex_unlock(&account_mutex);
}

void sem_wait_deposit() {
    sem_wait(&deposit_sem);
}

void sem_post_deposit() {
    sem_post(&deposit_sem);
}

void log_transaction(int customer_id, const char* op, int amount, int balance_after, int status) {
    FILE* f = fopen(RACE_LOG_FILE, "a");
    if (f) {
        transaction_count++;
        fprintf(f, "%-6d  %-12d  %-10s  %-8d  %-14d  %-8s\n",
                transaction_count,
                customer_id,
                op,
                amount,
                balance_after,
                status == STATUS_SUCCESS ? "OK" : "FAIL");
        fclose(f);
    }
}

int deposit(Account* acc, int amount, int customer_id) {
    if (amount <= 0) {
        log_transaction(customer_id, "DEPOSIT", amount, acc->balance, STATUS_FAILED);
        return STATUS_FAILED;
    }

    sem_wait_deposit();
    mutex_lock_account();

    acc->balance += amount;
    int new_balance = acc->balance;

    mutex_unlock_account();
    sem_post_deposit();

    log_transaction(customer_id, "DEPOSIT", amount, new_balance, STATUS_SUCCESS);
    return STATUS_SUCCESS;
}

int withdraw(Account* acc, int amount, int customer_id) {
    if (amount <= 0) {
        log_transaction(customer_id, "WITHDRAW", amount, acc->balance, STATUS_FAILED);
        return STATUS_FAILED;
    }

    mutex_lock_account();

    if (acc->balance < amount) {
        int current = acc->balance;
        mutex_unlock_account();
        log_transaction(customer_id, "WITHDRAW", amount, current, STATUS_FAILED);
        return STATUS_FAILED;
    }

    acc->balance -= amount;
    int new_balance = acc->balance;

    mutex_unlock_account();

    log_transaction(customer_id, "WITHDRAW", amount, new_balance, STATUS_SUCCESS);
    return STATUS_SUCCESS;
}

void print_race_log() {
    printf("  Transactions : %d\n", transaction_count);
    printf("  Mutex        : pthread_mutex_t (per account)\n");
    printf("  Semaphore    : max %d concurrent deposits\n", MAX_CONCURRENT_DEPOSITS);
    printf("  Log saved to : %s\n", RACE_LOG_FILE);
}
