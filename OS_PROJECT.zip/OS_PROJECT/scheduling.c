#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "common.h"
#include "sync.h"
#include "scheduling.h"

static int pipe_fd[2];

Customer create_customer(int id, char* name, int type, int arrival_time, int burst_time) {
    Customer c;
    c.id             = id;
    c.type           = type;
    c.priority       = type;
    c.arrival_time   = arrival_time;
    c.burst_time     = burst_time;
    c.remaining_time = burst_time;
    c.waiting_time   = 0;
    c.turnaround_time= 0;
    strncpy(c.name, name, MAX_NAME_LEN);
    c.account.account_id = id;
    c.account.owner_id   = id;
    c.account.balance    = 1000;
    return c;
}

static void* payroll_thread_fn(void* arg) {
    Customer* c = (Customer*)arg;
    deposit(&c->account, 100, c->id);
    return NULL;
}

void* customer_thread_fn(void* arg) {
    Customer* c = (Customer*)arg;

    if (c->type == TYPE_CORPORATE) {
        printf("  Corporate client %s spawning 3 payroll threads\n", c->name);
        pthread_t payroll[3];
        for (int i = 0; i < 3; i++)
            pthread_create(&payroll[i], NULL, payroll_thread_fn, (void*)c);
        for (int i = 0; i < 3; i++)
            pthread_join(payroll[i], NULL);
        printf("  Corporate client %s payroll complete  balance: %d\n",
               c->name, c->account.balance);
        return NULL;
    }

    Request req;
    req.customer_id = c->id;
    req.account_id  = c->account.account_id;
    req.amount      = 200;
    req.priority    = c->priority;

    if (c->type == TYPE_LOAN) {
        req.operation = OP_LOAN_REQUEST;
    } else {
        req.operation = (c->id % 2 == 0) ? OP_DEPOSIT : OP_WITHDRAW;
    }

    ipc_send_request(&req);

    Request received;
    ipc_receive_request(&received);

    Response res;
    res.customer_id = c->id;
    res.account_id  = c->account.account_id;

    if (received.operation == OP_DEPOSIT) {
        res.status = deposit(&c->account, received.amount, c->id);
    } else if (received.operation == OP_WITHDRAW) {
        res.status = withdraw(&c->account, received.amount, c->id);
    } else {
        res.status = STATUS_SUCCESS;
    }

    res.new_balance = c->account.balance;
    ipc_send_response(&res);
    ipc_log(&received, &res);

    return NULL;
}

void spawn_customer_thread(Customer* c) {
    pthread_create(&c->thread_id, NULL, customer_thread_fn, (void*)c);
}

void destroy_customer(Customer* c) {
    pthread_join(c->thread_id, NULL);
}

void scheduler_init(SchedulerQueue* q) {
    q->size = 0;
}

void schedule_fcfs(SchedulerQueue* q, GanttEntry* gantt, int* gantt_size) {
    int time = 0;
    *gantt_size = 0;

    for (int i = 0; i < q->size - 1; i++) {
        for (int j = 0; j < q->size - i - 1; j++) {
            if (q->customers[j]->arrival_time > q->customers[j+1]->arrival_time) {
                Customer* tmp      = q->customers[j];
                q->customers[j]   = q->customers[j+1];
                q->customers[j+1] = tmp;
            }
        }
    }

    for (int i = 0; i < q->size; i++) {
        Customer* c = q->customers[i];
        if (time < c->arrival_time)
            time = c->arrival_time;

        gantt[*gantt_size].customer_id = c->id;
        gantt[*gantt_size].start_time  = time;
        gantt[*gantt_size].end_time    = time + c->burst_time;
        (*gantt_size)++;

        c->waiting_time    = time - c->arrival_time;
        c->turnaround_time = c->waiting_time + c->burst_time;
        time              += c->burst_time;
    }
}

void schedule_priority(SchedulerQueue* q, GanttEntry* gantt, int* gantt_size) {
    int time = 0;
    *gantt_size = 0;

    for (int i = 0; i < q->size; i++) {
        q->customers[i]->remaining_time = q->customers[i]->burst_time;
    }

    int completed = 0;
    int prev = -1;

    while (completed < q->size) {
        int idx     = -1;
        int highest = -1;

        for (int i = 0; i < q->size; i++) {
            Customer* c = q->customers[i];
            if (c->arrival_time <= time && c->remaining_time > 0) {
                if (c->priority > highest) {
                    highest = c->priority;
                    idx     = i;
                }
            }
        }

        if (idx == -1) {
            time++;
            continue;
        }

        Customer* c = q->customers[idx];

        if (prev != idx) {
            gantt[*gantt_size].customer_id = c->id;
            gantt[*gantt_size].start_time  = time;
            gantt[*gantt_size].end_time    = time + 1;
            (*gantt_size)++;
        } else {
            gantt[*gantt_size - 1].end_time++;
        }

        c->remaining_time--;
        time++;
        prev = idx;

        if (c->remaining_time == 0) {
            c->turnaround_time = time - c->arrival_time;
            c->waiting_time    = c->turnaround_time - c->burst_time;
            completed++;
        }
    }
}

void schedule_rr(SchedulerQueue* q, GanttEntry* gantt, int* gantt_size) {
    int time = 0;
    *gantt_size = 0;

    for (int i = 0; i < q->size; i++)
        q->customers[i]->remaining_time = q->customers[i]->burst_time;

    int remaining = q->size;
    while (remaining > 0) {
        for (int i = 0; i < q->size; i++) {
            Customer* c = q->customers[i];
            if (c->remaining_time <= 0) continue;

            int slice = (c->remaining_time > TIME_QUANTUM) ? TIME_QUANTUM : c->remaining_time;

            gantt[*gantt_size].customer_id = c->id;
            gantt[*gantt_size].start_time  = time;
            gantt[*gantt_size].end_time    = time + slice;
            (*gantt_size)++;

            c->remaining_time -= slice;
            time              += slice;

            if (c->remaining_time == 0) {
                c->turnaround_time = time - c->arrival_time;
                c->waiting_time    = c->turnaround_time - c->burst_time;
                remaining--;
            }
        }
    }
}

void print_gantt_chart(GanttEntry* gantt, int size) {
    printf("\n  ");
    for (int i = 0; i < size; i++) printf("+------");
    printf("+\n  ");
    for (int i = 0; i < size; i++) printf("|  P%-2d ", gantt[i].customer_id);
    printf("|\n  ");
    for (int i = 0; i < size; i++) printf("+------");
    printf("+\n  ");
    printf("%-4d", gantt[0].start_time);
    for (int i = 0; i < size; i++) printf("   %-4d", gantt[i].end_time);
    printf("\n");
}

void calc_metrics(SchedulerQueue* q) {
    float total_wait = 0, total_turn = 0;

    printf("\n  %-4s  %-18s  %-10s  %-8s  %-8s\n",
           "ID", "Name", "Type", "Wait", "Turnaround");

    for (int i = 0; i < q->size; i++) {
        Customer* c = q->customers[i];
        const char* t =
            c->type == 5 ? "VIP"       :
            c->type == 3 ? "PREMIUM"   :
            c->type == 4 ? "CORPORATE" :
            c->type == 2 ? "LOAN"      : "REGULAR";
        printf("  %-4d  %-18s  %-10s  %-8d  %-8d\n",
               c->id, c->name, t,
               c->waiting_time, c->turnaround_time);
        total_wait += c->waiting_time;
        total_turn += c->turnaround_time;
    }

    printf("  Avg Wait: %.1f    Avg Turnaround: %.1f\n",
           total_wait / q->size, total_turn / q->size);
}

void ipc_init() {
    if (pipe(pipe_fd) == -1) {
        perror("pipe failed");
        exit(1);
    }

    FILE* f = fopen(IPC_LOG_FILE, "w");
    if (f) {
        fprintf(f, "%-12s %-12s %-10s %-10s %-10s %-12s\n",
                "CUSTOMER_ID", "ACCOUNT_ID", "OPERATION", "AMOUNT", "STATUS", "NEW_BALANCE");
        fprintf(f, "--------------------------------------------------------------------\n");
        fclose(f);
    }
}

void ipc_send_request(Request* req) {
    write(pipe_fd[1], req, sizeof(Request));
}

void ipc_receive_request(Request* req) {
    read(pipe_fd[0], req, sizeof(Request));
}

void ipc_send_response(Response* res) {
    FILE* f = fopen(IPC_LOG_FILE, "a");
    if (f) {
        fprintf(f, "%-12d %-12d %-10s %-10d %-10s %-12d\n",
                res->customer_id,
                res->account_id,
                "RESPONSE",
                res->new_balance,
                res->status == STATUS_SUCCESS ? "SUCCESS" : "FAILED",
                res->new_balance);
        fclose(f);
    }
}

void ipc_log(Request* req, Response* res) {
    FILE* f = fopen(IPC_LOG_FILE, "a");
    if (f) {
        fprintf(f, "%-12d %-12d %-10s %-10d %-10s %-12d\n",
                req->customer_id,
                req->account_id,
                req->operation == OP_DEPOSIT  ? "DEPOSIT"  :
                req->operation == OP_WITHDRAW ? "WITHDRAW" : "LOAN",
                req->amount,
                res->status == STATUS_SUCCESS ? "SUCCESS" : "FAILED",
                res->new_balance);
        fclose(f);
    }
}
