#ifndef SCHEDULING_H
#define SCHEDULING_H
#include "common.h"

Customer create_customer(int id, char* name, int type, int arrival_time, int burst_time);
void     spawn_customer_thread(Customer* c);
void*    customer_thread_fn(void* arg);
void     destroy_customer(Customer* c);

void scheduler_init(SchedulerQueue* q);
void schedule_fcfs(SchedulerQueue* q, GanttEntry* gantt, int* gantt_size);
void schedule_priority(SchedulerQueue* q, GanttEntry* gantt, int* gantt_size);
void schedule_rr(SchedulerQueue* q, GanttEntry* gantt, int* gantt_size);
void print_gantt_chart(GanttEntry* gantt, int size);
void calc_metrics(SchedulerQueue* q);

void ipc_init();
void ipc_send_request(Request* req);
void ipc_receive_request(Request* req);
void ipc_send_response(Response* res);
void ipc_log(Request* req, Response* res);
#endif
