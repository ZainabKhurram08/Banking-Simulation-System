#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "common.h"
#include "sync.h"
#include "memory.h"
#include "scheduling.h"
#include "banker.h"

#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define C_HEAD  "\033[38;5;147m"

static void section(const char* title) {
    int len = strlen(title);
    printf("\n%s%s%s%s\n", C_HEAD, BOLD, title, RESET);
    printf("%s", C_HEAD);
    for (int i = 0; i < len; i++) printf("\xe2\x95\x90");
    printf("%s\n", RESET);
}

static const char* type_str(int type) {
    switch (type) {
        case TYPE_VIP:       return "VIP";
        case TYPE_PREMIUM:   return "PREMIUM";
        case TYPE_CORPORATE: return "CORPORATE";
        case TYPE_LOAN:      return "LOAN";
        default:             return "REGULAR";
    }
}

static int load_customers(Customer* customers) {
    FILE* f = fopen("customers.txt", "r");
    if (!f) { printf("ERROR: customers.txt not found.\n"); exit(1); }

    int  count = 0;
    char type_buf[16];
    int  id, arrival, burst, balance;
    char name[MAX_NAME_LEN];

    while (fscanf(f, "%d %s %s %d %d %d",
                  &id, name, type_buf, &arrival, &burst, &balance) == 6) {
        int type = TYPE_REGULAR;
        if      (strcmp(type_buf, "VIP")       == 0) type = TYPE_VIP;
        else if (strcmp(type_buf, "PREMIUM")   == 0) type = TYPE_PREMIUM;
        else if (strcmp(type_buf, "CORPORATE") == 0) type = TYPE_CORPORATE;
        else if (strcmp(type_buf, "LOAN")      == 0) type = TYPE_LOAN;

        customers[count] = create_customer(id, name, type, arrival, burst);
        customers[count].account.balance = balance;
        count++;
    }
    fclose(f);
    return count;
}

static void reset_times(Customer* customers, int count) {
    for (int i = 0; i < count; i++) {
        customers[i].waiting_time    = 0;
        customers[i].turnaround_time = 0;
        customers[i].remaining_time  = customers[i].burst_time;
    }
}

static void run_scheduling(Customer* customers, int count) {
    SchedulerQueue q;
    GanttEntry     gantt[MAX_QUEUE_SIZE * 10];
    int            gantt_size = 0;

    scheduler_init(&q);
    for (int i = 0; i < count; i++)
        q.customers[q.size++] = &customers[i];

    section("1. SCHEDULING");

    printf("\n[FCFS] First Come First Serve\n");
    schedule_fcfs(&q, gantt, &gantt_size);
    print_gantt_chart(gantt, gantt_size);
    calc_metrics(&q);
    reset_times(customers, count);

    printf("\n[PRIORITY] Priority Scheduling (Preemptive)\n");
    schedule_priority(&q, gantt, &gantt_size);
    print_gantt_chart(gantt, gantt_size);
    calc_metrics(&q);
    reset_times(customers, count);

    printf("\n[RR] Round Robin  (Quantum = %dms)\n", TIME_QUANTUM);
    schedule_rr(&q, gantt, &gantt_size);
    print_gantt_chart(gantt, gantt_size);
    calc_metrics(&q);
    reset_times(customers, count);
}

static void run_threads(Customer* customers, int count) {
    section("2. THREADING");
    printf("Spawning %d customer threads\n\n", count);

    for (int i = 0; i < count; i++) {
        spawn_customer_thread(&customers[i]);
        printf("  Thread %-3d  %-18s  [%s]\n",
               customers[i].id, customers[i].name, type_str(customers[i].type));
    }
    for (int i = 0; i < count; i++)
        destroy_customer(&customers[i]);

    printf("\n  All %d threads completed.\n", count);
}

static void run_synchronization(Customer* customers, int count) {
    section("3. SYNCHRONIZATION");
    printf("  Mutex : protects account balance on every update\n");
    printf("  Sema  : max %d concurrent deposits allowed\n\n", MAX_CONCURRENT_DEPOSITS);

    for (int i = 0; i < count; i++) {
        if (customers[i].type == TYPE_REGULAR || customers[i].type == TYPE_PREMIUM) {
            int ok = deposit(&customers[i].account, 300, customers[i].id);
            printf("  %-18s  DEPOSIT   300   balance: %d   [%s]\n",
                   customers[i].name, customers[i].account.balance,
                   ok == STATUS_SUCCESS ? "OK" : "FAIL");
        }
        if (customers[i].type == TYPE_VIP || customers[i].type == TYPE_CORPORATE) {
            int ok = withdraw(&customers[i].account, 150, customers[i].id);
            printf("  %-18s  WITHDRAW  150   balance: %d   [%s]\n",
                   customers[i].name, customers[i].account.balance,
                   ok == STATUS_SUCCESS ? "OK" : "FAIL");
        }
    }
    printf("\n  Log includes transactions from threads + direct calls\n");
    print_race_log();
}

static void run_banker(Customer* customers, int count) {
    section("4. DEADLOCK PREVENTION (Banker's Algorithm)");

    BankerState state;
    banker_init(&state, count, 3);

    int available[3] = {5, 5, 5};
    for (int j = 0; j < 3; j++)
        state.available[j] = available[j];

    for (int i = 0; i < count; i++) {
        state.maximum[i][0]    = 3 + (i % 3);
        state.maximum[i][1]    = 2 + (i % 2);
        state.maximum[i][2]    = 1 + (i % 3);
        state.allocation[i][0] = i % 2;
        state.allocation[i][1] = i % 2;
        state.allocation[i][2] = 0;
        state.need[i][0]       = state.maximum[i][0] - state.allocation[i][0];
        state.need[i][1]       = state.maximum[i][1] - state.allocation[i][1];
        state.need[i][2]       = state.maximum[i][2] - state.allocation[i][2];
    }

    run_test_cases(&state);
}

static void run_ipc() {
    section("5. IPC (Message Passing)");
    printf("  Mechanism    : Pipe-based (POSIX pipe)\n");
    printf("  Flow         : Customer  →  pipe_fd[1]  →  pipe_fd[0]  →  Bank Server\n\n");
    printf("  Request  format : { customer_id, account_id, operation, amount, priority }\n");
    printf("  Response format : { customer_id, account_id, status, new_balance }\n\n");
    printf("  Operations supported:\n");
    printf("    DEPOSIT    →  customer sends amount  →  bank credits account\n");
    printf("    WITHDRAW   →  customer sends amount  →  bank debits account\n");
    printf("    LOAN       →  request forwarded to Banker's Algorithm\n\n");
    printf("  Each thread sends request via ipc_send_request()\n");
    printf("  Bank reads  via ipc_receive_request() and processes\n");
    printf("  Response logged via ipc_send_response() + ipc_log()\n\n");
    printf("  Log saved to : %s\n", IPC_LOG_FILE);
}

static void run_memory() {
    section("6. MEMORY MANAGEMENT (Page Replacement)");

    MemoryState fifo_state, lru_state;
    memory_init(&fifo_state, &lru_state, MAX_FRAMES);

    int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
    int n       = sizeof(pages) / sizeof(pages[0]);

    printf("  Reference string: ");
    for (int i = 0; i < n; i++) printf("%d ", pages[i]);
    printf("\n\n");

    run_fifo(&fifo_state, pages, n);
    run_lru(&lru_state,   pages, n);
    compare_algorithms(&fifo_state, &lru_state);
}

static void print_summary(int count) {
    printf("\n%s", C_HEAD);
    for (int i = 0; i < 50; i++) printf("\xe2\x95\x90");
    printf("\n%s%s  SIMULATION COMPLETE%s\n%s",
           RESET, C_HEAD, RESET, C_HEAD);
    for (int i = 0; i < 50; i++) printf("\xe2\x95\x90");
    printf("%s\n\n", RESET);

    printf("  Customers processed : %d\n", count);
    printf("  Schedulers run      : 3 (FCFS, Priority, Round Robin)\n");
    printf("  Log files saved     :\n");
    printf("  %-30s  IPC log\n",             IPC_LOG_FILE);
    printf("  %-30s  Race condition proof\n", RACE_LOG_FILE);
    printf("  %-30s  Page fault report\n",    PAGE_LOG_FILE);
    printf("\n%s", C_HEAD);
    for (int i = 0; i < 50; i++) printf("\xe2\x95\x90");
    printf("%s\n\n", RESET);
}

int main() {
    const char* title = "  Banking Simulation System  ";
    int len = strlen(title);

    printf("\n%s", C_HEAD);
    printf("  \xe2\x95\x94");
    for (int i = 0; i < len; i++) printf("\xe2\x95\x90");
    printf("\xe2\x95\x97\n");
    printf("  \xe2\x95\x91%s\xe2\x95\x91\n", title);
    printf("  \xe2\x95\x9a");
    for (int i = 0; i < len; i++) printf("\xe2\x95\x90");
    printf("\xe2\x95\x9d\n\n%s", RESET);

    Customer customers[MAX_CUSTOMERS];
    int count = 0;

    sync_init();
    ipc_init();

    count = load_customers(customers);
    printf("  Loaded %d customers from customers.txt\n\n", count);

    run_scheduling(customers, count);
    run_threads(customers, count);
    run_synchronization(customers, count);
    run_banker(customers, count);
    run_ipc();
    run_memory();
    print_summary(count);

    sync_destroy();
    return 0;
}
