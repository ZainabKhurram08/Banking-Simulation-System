#ifndef COMMON_H
#define COMMON_H

#include <pthread.h>
#include <semaphore.h>

#define MAX_CUSTOMERS           20
#define MAX_RESOURCES            5
#define MAX_FRAMES               4
#define MAX_PAGES               10
#define MAX_NAME_LEN            50
#define MAX_LOG_LEN            256
#define MAX_QUEUE_SIZE          20
#define TIME_QUANTUM             2
#define MAX_CONCURRENT_DEPOSITS  2

#define TYPE_REGULAR     1
#define TYPE_LOAN        2
#define TYPE_PREMIUM     3
#define TYPE_CORPORATE   4
#define TYPE_VIP         5

#define SCHED_FCFS       0
#define SCHED_PRIORITY   1
#define SCHED_RR         2

#define OP_DEPOSIT       1
#define OP_WITHDRAW      2
#define OP_LOAN_REQUEST  3
#define OP_LOAN_RELEASE  4

#define STATUS_SUCCESS   1
#define STATUS_FAILED    0
#define STATUS_SAFE      1
#define STATUS_UNSAFE    0

#define IPC_LOG_FILE     "ipc_log.txt"
#define RACE_LOG_FILE    "race_condition_log.txt"
#define PAGE_LOG_FILE    "page_fault_log.txt"

typedef struct {
    int account_id;
    int owner_id;
    int balance;
} Account;

typedef struct {
    int       id;
    char      name[MAX_NAME_LEN];
    int       type;
    int       priority;
    int       arrival_time;
    int       burst_time;
    int       waiting_time;
    int       turnaround_time;
    int       remaining_time;
    Account   account;
    pthread_t thread_id;
} Customer;

typedef struct {
    int customer_id;
    int account_id;
    int operation;
    int amount;
    int priority;
} Request;

typedef struct {
    int  customer_id;
    int  account_id;
    int  status;
    int  new_balance;
    char message[MAX_LOG_LEN];
} Response;

typedef struct {
    int allocation[MAX_CUSTOMERS][MAX_RESOURCES];
    int maximum[MAX_CUSTOMERS][MAX_RESOURCES];
    int available[MAX_RESOURCES];
    int need[MAX_CUSTOMERS][MAX_RESOURCES];
    int num_customers;
    int num_resources;
} BankerState;

typedef struct {
    int frames[MAX_FRAMES];
    int page_faults;
    int page_hits;
    int num_frames;
    int num_accesses;
} MemoryState;

typedef struct {
    int customer_id;
    int start_time;
    int end_time;
} GanttEntry;

typedef struct {
    Customer* customers[MAX_QUEUE_SIZE];
    int       size;
} SchedulerQueue;

extern pthread_mutex_t account_mutex;
extern sem_t           deposit_sem;

#endif
