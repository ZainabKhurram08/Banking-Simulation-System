#include <stdio.h>
#include <string.h>
#include "common.h"
#include "memory.h"

static int fifo_queue[MAX_FRAMES];
static int fifo_front = 0;

void memory_init(MemoryState* fifo, MemoryState* lru, int num_frames) {
    fifo->page_faults  = 0;
    fifo->page_hits    = 0;
    fifo->num_frames   = num_frames;
    fifo->num_accesses = 0;

    lru->page_faults   = 0;
    lru->page_hits     = 0;
    lru->num_frames    = num_frames;
    lru->num_accesses  = 0;

    for (int i = 0; i < MAX_FRAMES; i++) {
        fifo->frames[i] = -1;
        lru->frames[i]  = -1;
        fifo_queue[i]   = -1;
    }

    fifo_front = 0;

    FILE* f = fopen(PAGE_LOG_FILE, "w");
    if (f) {
        fprintf(f, "PAGE REPLACEMENT LOG\n\n");
        fprintf(f, "%-8s  %-6s  %-6s  %-30s  %-10s\n",
                "ALGO", "PAGE", "EVENT", "FRAMES", "FAULTS");
        fprintf(f, "\n");
        fclose(f);
    }
}

static int is_in_frames(MemoryState* state, int page) {
    for (int i = 0; i < state->num_frames; i++) {
        if (state->frames[i] == page)
            return 1;
    }
    return 0;
}

static void log_page_event(const char* algo, int page, const char* event,
                           MemoryState* state, int faults) {
    FILE* f = fopen(PAGE_LOG_FILE, "a");
    if (!f) return;

    char frame_str[64] = "[";
    for (int i = 0; i < state->num_frames; i++) {
        char tmp[8];
        if (state->frames[i] == -1)
            snprintf(tmp, sizeof(tmp), " - ");
        else
            snprintf(tmp, sizeof(tmp), " %d ", state->frames[i]);
        strcat(frame_str, tmp);
    }
    strcat(frame_str, "]");

    fprintf(f, "%-8s %-6d %-6s %-30s %-10d\n",
            algo, page, event, frame_str, faults);
    fclose(f);
}

int fifo_replace(MemoryState* state, int page) {
    int replaced = state->frames[fifo_front];
    state->frames[fifo_front] = page;
    fifo_front = (fifo_front + 1) % state->num_frames;
    return replaced;
}

void page_access_fifo(MemoryState* state, int page) {
    state->num_accesses++;

    if (is_in_frames(state, page)) {
        state->page_hits++;
        log_page_event("FIFO", page, "HIT", state, state->page_faults);
        return;
    }

    state->page_faults++;

    int empty_slot = -1;
    for (int i = 0; i < state->num_frames; i++) {
        if (state->frames[i] == -1) {
            empty_slot = i;
            break;
        }
    }

    if (empty_slot != -1) {
        state->frames[empty_slot] = page;
        fifo_queue[empty_slot]    = page;
    } else {
        fifo_replace(state, page);
    }

    log_page_event("FIFO", page, "FAULT", state, state->page_faults);
}

int lru_replace(MemoryState* state, int page, int* lru_order, int access_index) {
    int lru_idx  = 0;
    int min_time = lru_order[0];

    for (int i = 1; i < state->num_frames; i++) {
        if (lru_order[i] < min_time) {
            min_time = lru_order[i];
            lru_idx  = i;
        }
    }

    int replaced        = state->frames[lru_idx];
    state->frames[lru_idx] = page;
    lru_order[lru_idx]  = access_index;
    return replaced;
}

void page_access_lru(MemoryState* state, int page, int* lru_order, int access_index) {
    state->num_accesses++;

    for (int i = 0; i < state->num_frames; i++) {
        if (state->frames[i] == page) {
            state->page_hits++;
            lru_order[i] = access_index;
            log_page_event("LRU", page, "HIT", state, state->page_faults);
            return;
        }
    }

    state->page_faults++;

    int empty_slot = -1;
    for (int i = 0; i < state->num_frames; i++) {
        if (state->frames[i] == -1) {
            empty_slot = i;
            break;
        }
    }

    if (empty_slot != -1) {
        state->frames[empty_slot] = page;
        lru_order[empty_slot]     = access_index;
    } else {
        lru_replace(state, page, lru_order, access_index);
    }

    log_page_event("LRU", page, "FAULT", state, state->page_faults);
}

void run_fifo(MemoryState* state, int* pages, int num_pages) {
    fifo_front = 0;
    for (int i = 0; i < num_pages; i++) {
        page_access_fifo(state, pages[i]);
    }
}

void run_lru(MemoryState* state, int* pages, int num_pages) {
    int lru_order[MAX_FRAMES];
    for (int i = 0; i < MAX_FRAMES; i++)
        lru_order[i] = -1;

    for (int i = 0; i < num_pages; i++) {
        page_access_lru(state, pages[i], lru_order, i);
    }
}

void print_page_faults(MemoryState* fifo, MemoryState* lru) {
    float fifo_hit_ratio = fifo->num_accesses > 0
        ? (float)fifo->page_hits / fifo->num_accesses * 100.0f : 0;
    float lru_hit_ratio  = lru->num_accesses > 0
        ? (float)lru->page_hits  / lru->num_accesses  * 100.0f : 0;

    printf("\n  Page Fault Results\n\n");
    printf("  %-12s  %-12s  %-10s  %-10s\n",
           "Algorithm", "Page Faults", "Page Hits", "Hit Ratio");
    printf("  %-12s  %-12d  %-10d  %.2f%%\n",
           "FIFO", fifo->page_faults, fifo->page_hits, fifo_hit_ratio);
    printf("  %-12s  %-12d  %-10d  %.2f%%\n",
           "LRU",  lru->page_faults,  lru->page_hits,  lru_hit_ratio);
    printf("\n");

    if (lru->page_faults < fifo->page_faults)
        printf("  LRU performed better (fewer page faults)\n");
    else if (fifo->page_faults < lru->page_faults)
        printf("  FIFO performed better (fewer page faults)\n");
    else
        printf("  Both algorithms performed equally\n");
}

void compare_algorithms(MemoryState* fifo, MemoryState* lru) {
    print_page_faults(fifo, lru);

    FILE* f = fopen(PAGE_LOG_FILE, "a");
    if (f) {
        float fifo_ratio = fifo->num_accesses > 0
            ? (float)fifo->page_hits / fifo->num_accesses * 100.0f : 0;
        float lru_ratio  = lru->num_accesses > 0
            ? (float)lru->page_hits  / lru->num_accesses  * 100.0f : 0;

        fprintf(f, "\nSUMMARY\n");
        fprintf(f, "%-12s %-14s %-12s %-12s\n",
                "ALGORITHM", "PAGE FAULTS", "PAGE HITS", "HIT RATIO");
        fprintf(f, "%-12s %-14d %-12d %.2f%%\n",
                "FIFO", fifo->page_faults, fifo->page_hits, fifo_ratio);
        fprintf(f, "%-12s %-14d %-12d %.2f%%\n",
                "LRU",  lru->page_faults,  lru->page_hits,  lru_ratio);
        fclose(f);
    }

}
